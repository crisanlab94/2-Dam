package es.ejemplo.android.fichaje_diario;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class recursosActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recursoshumanos);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) GridView grid = findViewById(R.id.miGridTrabajadores);

        // Trabajadores reales del gimnasio
        final String[] monitores = new String[]{
                "Trabajador a ", "Trabajador b ", "Trabajador c",
                "Trabajador d ",

        };


        ArrayAdapter<String> adaptador = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                monitores
        );

        grid.setAdapter(adaptador);


    }

    // --- GESTIÓN DE MENÚ DE OPCIONES (Toolbar superior) ---
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_trabajador, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Lógica para las acciones del administrador/técnico
        Toast.makeText(this, "Opción: " + item.getTitle(), Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }



    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Log.i("menus", "Acción seleccionada: " + item.getTitle());
        Toast.makeText(this, "Has pulsado: " + item.getTitle(), Toast.LENGTH_SHORT).show();
        return super.onContextItemSelected(item);
    }
}



