package es.ejemplo.android.fichaje_diario;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;




import es.ejemplo.android.fichaje_diario.MainActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText txtUsuario;
    private EditText txtPassword;
    private Button btnEntrar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtUsuario = findViewById(R.id.txtUsuario);
        txtPassword = findViewById(R.id.txtPassword);
        btnEntrar = findViewById(R.id.btnEntrar);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String usuario = txtUsuario.getText().toString().trim();
                String pass = txtPassword.getText().toString().trim();

                // 1) Si falta algo → Toast
                if (usuario.isEmpty() || pass.isEmpty()) {
                    Toast toast = Toast.makeText(
                            getApplicationContext(),
                            "Rellena usuario y contraseña",
                            Toast.LENGTH_LONG
                    );
                    toast.show();
                    return;
                }

                // 2) Comprobación sencilla
                if (usuario.equals("rrhh") && pass.equals("rrhh")) {
                    // Login correcto → pasamos a MainActivity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // cerramos login
                }else if (usuario.equals("trabajador") && pass.equals("trabajador")) {
                    // Login correcto → pasamos a MainActivity
                    Intent intent = new Intent(LoginActivity.this, recursosActivity.class);
                    startActivity(intent);
                    finish();


                } else {
                    // Login incorrecto → Diálogo
                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                    builder.setMessage("Usuario o contraseña incorrectos")
                            .setTitle("Error de acceso")
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setPositiveButton("Reintentar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.i("Login", "Reintentar pulsado");
                                }
                            })
                            .setNegativeButton("Salir", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.i("Login", "Salir pulsado");
                                    finish();
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });
    }
}
