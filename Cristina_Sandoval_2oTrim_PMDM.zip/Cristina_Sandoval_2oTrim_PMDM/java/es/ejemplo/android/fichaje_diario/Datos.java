package es.ejemplo.android.fichaje_diario;

public class Datos {
    private String texto1;
    private String texto2;
    public Datos (String texto1, String texto2){
        this.texto1= texto1;
        this.texto2= texto2;
    }
    public String getTexto1(){
        return texto1;
    }
    public String getTexto2(){
        return texto2;
    }
}


