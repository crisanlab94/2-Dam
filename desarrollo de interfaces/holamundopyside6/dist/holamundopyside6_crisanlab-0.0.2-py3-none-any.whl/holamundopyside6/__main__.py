def main():
    print("Hola mundo desde PyPI")
if __name__ == "__main__":
    main()