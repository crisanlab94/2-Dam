package com.example.proyecto4;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    private static int contador = 1;
    private String fechaSel = "";
    private EditText etNom, etEm, etCl;
    private AutoCompleteTextView acProv;
    private TextView tvFec, tvIdCont;
    private CheckBox cbTerm;
    private Button btnAccion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        vincularVistas();

        String[] provincias = {"Sevilla", "Cádiz", "Huelva", "Málaga", "Córdoba", "Granada"};
        acProv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, provincias));

        tvFec.setOnClickListener(v -> {
            new DatePickerDialog(this, (view, y, m, d) -> {
                fechaSel = d + "/" + (m + 1) + "/" + y;
                tvFec.setText(fechaSel);
            }, 2026, 1, 3).show();
        });

        // MODO EDICIÓN: Carga los datos y cambia el botón
        Estudiante edit = (Estudiante) getIntent().getSerializableExtra("edit_estudiante");
        if (edit != null) {
            tvIdCont.setText("ID: " + edit.getIdEntidad());
            etNom.setText(edit.getNombre());
            etEm.setText(edit.getEmail());
            etCl.setText(edit.getClave());
            tvFec.setText(edit.getFechaNacimiento());
            fechaSel = edit.getFechaNacimiento();
            btnAccion.setText("GUARDAR CAMBIOS");
        } else {
            tvIdCont.setText("ID: " + String.format("%03d", contador));
        }

        btnAccion.setOnClickListener(v -> {
            // VALIDACIÓN RESTAURADA: Los términos son obligatorios
            if (!cbTerm.isChecked()) {
                Toast.makeText(this, "Debe aceptar los términos para continuar", Toast.LENGTH_SHORT).show();
                return;
            }

            Snackbar.make(v, "¡Operación procesada con éxito!", Snackbar.LENGTH_LONG).show();

            String idActual = (edit != null) ? edit.getIdEntidad() : String.format("%03d", contador);
            Estudiante e = new Estudiante(idActual, etNom.getText().toString(), etEm.getText().toString(), etCl.getText().toString(), fechaSel);

            v.postDelayed(() -> {
                Intent intent = new Intent(this, SegundaActivity.class);
                intent.putExtra("estudiante", e);
                startActivity(intent);
                if (edit == null) contador++;
                finish();
            }, 1200);
        });

        findViewById(R.id.btnSalirRegistro).setOnClickListener(v -> finish());
    }

    private void vincularVistas() {
        etNom = findViewById(R.id.etNombre); etEm = findViewById(R.id.etEmail);
        etCl = findViewById(R.id.etClave); acProv = findViewById(R.id.acProvincia);
        tvFec = findViewById(R.id.tvFechaTrigger); cbTerm = findViewById(R.id.cbTerminos);
        btnAccion = findViewById(R.id.btnRegistrar); tvIdCont = findViewById(R.id.tvIdContador);
    }
}