package com.example.proyecto4;

import java.util.ArrayList;

public class GestionCompartida {
    // Lista global que actúa como base de datos temporal en la sesión
    public static ArrayList<Datos> listaTutorias = new ArrayList<>();
}