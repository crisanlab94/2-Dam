package com.example.proyecto4;

import java.io.Serializable;

public class Estudiante implements java.io.Serializable {
    private String id, nom, em, cl, fec;
    public Estudiante(String id, String nom, String em, String cl, String fec) {
        this.id = id; this.nom = nom; this.em = em; this.cl = cl; this.fec = fec;
    }
    public String getIdEntidad() { return id; }
    public String getNombre() { return nom; }
    public String getEmail() { return em; }
    public String getClave() { return cl; }
    public String getFechaNacimiento() { return fec; }
}