package com.example.proyecto4;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.btnLoginEstudiante).setOnClickListener(v -> {
            // Pasamos un objeto vacío para evitar el error "No hay datos"
            Estudiante invitado = new Estudiante("000", "Invitado", "inv@email.com", "", "");
            Intent intent = new Intent(this, HomeEstudianteActivity.class);
            intent.putExtra("estudiante", invitado);
            startActivity(intent);
        });

        findViewById(R.id.btnLoginAdmin).setOnClickListener(v -> startActivity(new Intent(this, HomeAdminActivity.class)));
        findViewById(R.id.btnIrRegistro).setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
    }
}