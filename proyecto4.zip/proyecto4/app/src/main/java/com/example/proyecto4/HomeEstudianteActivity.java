package com.example.proyecto4;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class HomeEstudianteActivity extends AppCompatActivity {
    private Estudiante estudianteActual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_estudiante);

        Toolbar toolbar = findViewById(R.id.toolbar_home_estudiante);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayShowTitleEnabled(false);

        // Recogemos los datos reales para evitar el Toast de error
        estudianteActual = (Estudiante) getIntent().getSerializableExtra("estudiante");

        findViewById(R.id.btnMiFicha).setOnClickListener(v -> {
            if (estudianteActual != null) {
                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra("edit_estudiante", estudianteActual);
                startActivity(intent);
            } else {
                Toast.makeText(this, "No hay datos de perfil", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnReservarTutoria).setOnClickListener(v -> {
            new DatePickerDialog(this, (view, y, m, d) -> {
                String fecha = d + "/" + (m + 1);
                new TimePickerDialog(this, (vT, h, min) -> {
                    String n = (estudianteActual != null) ? estudianteActual.getNombre() : "Alumno";
                    GestionCompartida.listaTutorias.add(new Datos("Alumno: " + n, fecha + " a las " + h + ":" + min));
                    Toast.makeText(this, "Reserva confirmada", Toast.LENGTH_SHORT).show();
                }, 12, 0, true).show();
            }, 2026, 1, 10).show();
        });

        findViewById(R.id.btnCerrarSesion).setOnClickListener(v -> finish());
        findViewById(R.id.btnAyudaTecnica).setOnClickListener(v -> mostrarAyuda());
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) { getMenuInflater().inflate(R.menu.main_menu, menu); return true; }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.home) {
            startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            return true;
        }
        if (id == R.id.menu_valorar) { mostrarValoracion(); return true; }
        if (id == R.id.contact) { mostrarAyuda(); return true; }
        return super.onOptionsItemSelected(item);
    }

    public void mostrarValoracion() {
        final RatingBar rb = new RatingBar(this); rb.setNumStars(5);
        rb.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER); l.setPadding(50,50,50,50); l.addView(rb);
        new AlertDialog.Builder(this).setTitle("Valora la App").setView(l)
                .setPositiveButton("OK", (d, w) -> // MENSAJE RESTAURADO
                        Toast.makeText(this, "Has valorado con " + rb.getRating() + " estrellas", Toast.LENGTH_SHORT).show()).show();
    }

    public void mostrarAyuda() {
        String[] ops = {"Email", "Chat"};
        new AlertDialog.Builder(this).setTitle("Contacto").setItems(ops, (d, w) ->
                Toast.makeText(this, "Contactando vía " + ops[w] + "...", Toast.LENGTH_SHORT).show()).show();
    }
}