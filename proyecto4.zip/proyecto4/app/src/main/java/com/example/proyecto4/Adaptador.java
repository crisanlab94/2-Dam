package com.example.proyecto4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class Adaptador extends BaseAdapter {
    private Context context;
    private ArrayList<Datos> lista;
    public Adaptador(Context context, ArrayList<Datos> lista) { this.context = context; this.lista = lista; }
    @Override public int getCount() { return lista.size(); }
    @Override public Object getItem(int p) { return lista.get(p); }
    @Override public long getItemId(int p) { return p; }
    @Override public View getView(int p, View v, ViewGroup parent) {
        if (v == null) v = LayoutInflater.from(context).inflate(R.layout.elemento, parent, false);
        TextView txt1 = v.findViewById(R.id.miTextol);
        TextView txt2 = v.findViewById(R.id.miTexto2);
        txt1.setText(lista.get(p).getTitulo());
        txt2.setText(lista.get(p).getSubtitulo());
        return v;
    }
}