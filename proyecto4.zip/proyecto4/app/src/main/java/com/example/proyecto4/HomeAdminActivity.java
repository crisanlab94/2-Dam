package com.example.proyecto4;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class HomeAdminActivity extends AppCompatActivity {
    private Adaptador ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_admin);

        Toolbar toolbar = findViewById(R.id.toolbar_admin);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayShowTitleEnabled(false);

        Spinner sp = findViewById(R.id.miSpinner);
        sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"1º DAW", "2º DAW"}));

        ListView lv = findViewById(R.id.lvGestionTutorias);
        ad = new Adaptador(this, GestionCompartida.listaTutorias);
        lv.setAdapter(ad);

        // RESTAURADO: Gestión de citas (reprogramar/cancelar) al pulsar en la lista
        lv.setOnItemClickListener((p, v, pos, id) -> {
            String[] ops = {"Reprogramar Cita", "Cancelar Cita"};
            new AlertDialog.Builder(this).setTitle("Gestión").setItems(ops, (d, w) -> {
                if (w == 0) {
                    new DatePickerDialog(this, (vD, y, m, day) -> {
                        new TimePickerDialog(this, (vT, h, min) -> {
                            Datos actual = GestionCompartida.listaTutorias.get(pos);
                            actual.setSubtitulo("Reprogramada: " + day + "/" + (m+1) + " a las " + h + ":" + min);
                            ad.notifyDataSetChanged();
                        }, 10, 0, true).show();
                    }, 2026, 1, 15).show();
                } else {
                    GestionCompartida.listaTutorias.remove(pos); ad.notifyDataSetChanged();
                }
            }).show();
        });

        findViewById(R.id.btnAbrirPopup).setOnClickListener(v -> {
            PopupMenu p = new PopupMenu(this, v);
            p.getMenu().add("Exportar PDF"); p.getMenu().add("Enviar Email");
            p.setOnMenuItemClickListener(item -> {
                String msg = item.getTitle().equals("Exportar PDF") ? "Exportando en PDF..." : "Enviando por email...";
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
                return true;
            });
            p.show();
        });

        findViewById(R.id.btnSalirApp).setOnClickListener(v -> finish());
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) { getMenuInflater().inflate(R.menu.main_menu, menu); return true; }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.home) {
            startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            return true;
        }
        if (id == R.id.menu_valorar) { mostrarValoracion(); return true; }
        if (id == R.id.contact) { mostrarAyuda(); return true; }
        return super.onOptionsItemSelected(item);
    }

    public void mostrarValoracion() {
        final RatingBar rb = new RatingBar(this); rb.setNumStars(5);
        rb.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER); l.setPadding(50,50,50,50); l.addView(rb);
        new AlertDialog.Builder(this).setTitle("Valora la App").setView(l)
                .setPositiveButton("OK", (d, w) ->
                        Toast.makeText(this, "Feedback: " + rb.getRating() + " estrellas", Toast.LENGTH_SHORT).show()).show();
    }

    public void mostrarAyuda() {
        Toast.makeText(this, "Contactando con soporte...", Toast.LENGTH_SHORT).show();
    }
}