package com.example.proyecto4;

import java.io.Serializable;

public class Datos implements java.io.Serializable {
    private String titulo, subtitulo;
    public Datos(String t, String s) { this.titulo = t; this.subtitulo = s; }
    public String getTitulo() { return titulo; }
    public String getSubtitulo() { return subtitulo; }
    public void setSubtitulo(String s) { this.subtitulo = s; }
}