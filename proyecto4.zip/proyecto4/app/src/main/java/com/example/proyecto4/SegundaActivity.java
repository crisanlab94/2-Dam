package com.example.proyecto4;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class SegundaActivity extends AppCompatActivity {
    private Estudiante e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        Toolbar toolbar = findViewById(R.id.toolbar_segunda);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayShowTitleEnabled(false);

        e = (Estudiante) getIntent().getSerializableExtra("estudiante");
        if (e != null) {
            String res = "ID: " + e.getIdEntidad() + "\nNombre: " + e.getNombre() + "\nEmail: " + e.getEmail() + "\nFecha: " + e.getFechaNacimiento();
            ((TextView)findViewById(R.id.tvResumen)).setText(res);
        }

        findViewById(R.id.btnActualizarPerfil).setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class).putExtra("edit_estudiante", e)));

        // PASO CLAVE: Reenvío al Panel Estudiante
        findViewById(R.id.btnVolverRegistro).setOnClickListener(v -> {
            Intent intent = new Intent(this, HomeEstudianteActivity.class);
            intent.putExtra("estudiante", e);
            startActivity(intent);
            finish();
        });
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) { getMenuInflater().inflate(R.menu.main_menu, menu); return true; }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.home) {
            startActivity(new Intent(this, LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            return true;
        }
        if (id == R.id.menu_valorar) { mostrarValoracion(); return true; }
        if (id == R.id.contact) { mostrarAyuda(); return true; }
        return super.onOptionsItemSelected(item);
    }

    public void mostrarValoracion() {
        final RatingBar rb = new RatingBar(this); rb.setNumStars(5);
        LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER); l.setPadding(50,50,50,50); l.addView(rb);
        new AlertDialog.Builder(this).setTitle("Valorar").setView(l)
                .setPositiveButton("OK", (d, w) ->
                        Toast.makeText(this, "Gracias por tus " + rb.getRating() + " estrellas", Toast.LENGTH_SHORT).show()).show();
    }

    public void mostrarAyuda() { //
        String[] ops = {"Email", "Chat"};
        new AlertDialog.Builder(this).setTitle("Contacto").setItems(ops, (d, w) ->
                Toast.makeText(this, "Abriendo " + ops[w] + "...", Toast.LENGTH_SHORT).show()).show();
    }
}